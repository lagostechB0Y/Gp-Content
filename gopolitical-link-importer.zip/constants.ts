export const CATEGORIES = [
    "Civic Tech", "Climate", "Culture", "Economy", "Editorials", "Fact-Check",
    "General News", "Global", "Governance", "Investigations", "Local Governance",
    "Opinion", "Politics", "State Affairs", "Women in Politics", "Youth in Politics"
];
